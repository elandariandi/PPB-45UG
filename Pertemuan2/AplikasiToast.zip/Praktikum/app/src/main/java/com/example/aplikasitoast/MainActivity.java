package com.example.aplikasitoast;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    TextView angka;
    int nilai = 0;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        angka = findViewById(R.id.kounter);
    }

    public void toastklik(View view) {
        Toast.makeText(this, "Hai Ini Adalah TOAST", Toast.LENGTH_SHORT).show();
    }

    public void tblkounter(View view) {
        nilai = nilai + 1;
        angka.setText(Integer.toString(nilai));
    }
}