package com.example.menurecyclerview;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import de.hdodenhof.circleimageview.CircleImageView;

public class DetailMakanan extends AppCompatActivity {

    public static final String ITEM_EXTRA = "item_extra";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail_makanan);

        CircleImageView imgMakanan = findViewById(R.id.detailgambar);
        TextView nmMakanan = findViewById(R.id.makanan_nama);
        TextView dtMakanan = findViewById(R.id.makanan_detail);
        TextView hgMakanan = findViewById(R.id.makanan_harga);

        Menu menu = getIntent().getParcelableExtra(ITEM_EXTRA);
        if (menu != null) {
            Glide.with(this)
                    .load(menu.getFoto())
                    .into(imgMakanan);
            nmMakanan.setText(menu.getNamamakanan());
            dtMakanan.setText(menu.getDetailmakanan());
            hgMakanan.setText(menu.getHargamakanan());
        }
        if (getSupportActionBar() != null) {
            getSupportActionBar().setTitle("Detail Makanan");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }
    }
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}