package com.example.menurecyclerview;

import android.os.Parcel;
import android.os.Parcelable;

public class Menu implements Parcelable {
    private String namamakanan;
    private String hargamakanan;
    private String detailmakanan;
    private int foto;

    protected Menu(Parcel in) {
        namamakanan = in.readString();
        hargamakanan = in.readString();
        detailmakanan = in.readString();
        foto = in.readInt();
    }

    public static final Creator<Menu> CREATOR = new Creator<Menu>() {
        @Override
        public Menu createFromParcel(Parcel in) {
            return new Menu(in);
        }

        @Override
        public Menu[] newArray(int size) {
            return new Menu[size];
        }
    };

    public Menu() {

    }

    public String getNamamakanan() {
        return namamakanan;
    }

    public void setNamamakanan(String namamakanan) {
        this.namamakanan = namamakanan;
    }

    public String getHargamakanan() {
        return hargamakanan;
    }

    public void setHargamakanan(String hargamakanan) {
        this.hargamakanan = hargamakanan;
    }

    public String getDetailmakanan() {
        return detailmakanan;
    }

    public void setDetailmakanan(String detailmakanan) {
        this.detailmakanan = detailmakanan;
    }

    public int getFoto() {
        return foto;
    }

    public void setFoto(int foto) {
        this.foto = foto;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel parcel, int i) {
        parcel.writeString(namamakanan);
        parcel.writeString(hargamakanan);
        parcel.writeString(detailmakanan);
        parcel.writeInt(foto);
    }
}
