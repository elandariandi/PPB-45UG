package com.example.menurecyclerview;

import java.util.ArrayList;

public class DataMakanan {
    private static String [] makananName = {
            "Ayam Goreng",
            "Ayam Bakar",
            "Nasi Goreng Ayam",
            "Nasi Goreng Spesial",
            "Soto Kudus",
            "Cah Kangkung"
    };

    private static String [] makananDetail = {
            "Ayam Goreng + Nasi + Sambal",
            "Ayam Bakar + Nasi + Sambal",
            "Nasi Goreng + Ayam Suwir + Kerupuk",
            "Nasi Goreng + Ayam Suwir + Babat + Sosis + Kerupuk",
            "Soto Kudus + Sate Telur Puyuh",
            "Kangkung + Tomat"
    };

    private static String [] makananHarga = {
            "15.000",
            "18.000",
            "12.000",
            "15.000",
            "16.000",
            "10.000"
    };

    private static int [] makananGambar = {
            R.drawable.ayam_goreng,
            R.drawable.ayam_bakar,
            R.drawable.nasi_goreng_ayam,
            R.drawable.nasi_goreng_spesial,
            R.drawable.soto_kudus,
            R.drawable.cah_kangkung
    };

    static ArrayList<Menu> getListData() {
        ArrayList<Menu> list = new ArrayList<>();
        for (int posisi = 0; posisi < makananName.length; posisi++) {
            Menu menu = new Menu();
            menu.setNamamakanan(makananName[posisi]);
            menu.setDetailmakanan(makananDetail[posisi]);
            menu.setHargamakanan(makananHarga[posisi]);
            menu.setFoto(makananGambar[posisi]);
            list.add(menu);
        }
        return list;
    }
}
