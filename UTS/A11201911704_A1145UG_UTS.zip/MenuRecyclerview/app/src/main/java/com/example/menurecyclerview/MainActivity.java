package com.example.menurecyclerview;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Toast;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {
    private RecyclerView rcyMenu;
    private ArrayList<Menu> list = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rcyMenu = findViewById(R.id.rcy_Menu);
        rcyMenu.setHasFixedSize(true);

        list.addAll(DataMakanan.getListData());
        showRecyclerList();
    }

    private void showRecyclerList() {
        rcyMenu.setLayoutManager(new LinearLayoutManager(this));
        AdapterMenu adapterMenu = new AdapterMenu(list);
        rcyMenu.setAdapter(adapterMenu);

        adapterMenu.setOnItemClickCallback(new AdapterMenu.OnItemClickCallback() {
            @Override
            public void onItemClicked(Menu data) {
                Intent moveIntent = new Intent(MainActivity.this,DetailMakanan.class);
                moveIntent.putExtra(DetailMakanan.ITEM_EXTRA, data);
                startActivity(moveIntent);
            }
        });
    }
}