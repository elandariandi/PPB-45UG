package com.example.menurecyclerview;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class AdapterMenu extends RecyclerView.Adapter<AdapterMenu.ListViewHolder> {
    private ArrayList<Menu> listMenu;

    private OnItemClickCallback onItemClickCallback;

    public void setOnItemClickCallback(OnItemClickCallback onItemClickCallback) {
        this.onItemClickCallback = onItemClickCallback;
    }

    public AdapterMenu(ArrayList<Menu> list) {
        this.listMenu = list;
    }

    @NonNull
    @Override
    public AdapterMenu.ListViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_list, parent, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull AdapterMenu.ListViewHolder holder, int position) {
        Menu menu = listMenu.get(position);
        Glide.with(holder.itemView.getContext())
                .load(menu.getFoto())
                .apply(new RequestOptions().override(50,50))
                .into(holder.imgPhoto);
        holder.txtName.setText(menu.getNamamakanan());
//        holder.txtDetail.setText(menu.getDetailmakanan());
        holder.txtPrice.setText(menu.getHargamakanan());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onItemClickCallback.onItemClicked(listMenu.get(holder.getAdapterPosition()));
            }
        });
    }

    @Override
    public int getItemCount() {
        return listMenu.size();
    }



    public class ListViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView txtName, txtPrice;

        public ListViewHolder(View itemview) {
            super(itemview);
            imgPhoto = itemview.findViewById(R.id.gambar_makanan);
            txtName = itemview.findViewById(R.id.nama_makanan);
//            txtDetail = itemview.findViewById(R.id.detail_makanan);
            txtPrice = itemview.findViewById(R.id.harga_makanan);
        }
    }

    public interface OnItemClickCallback {
        void onItemClicked(Menu data);
    }
}
