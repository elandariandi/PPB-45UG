package com.example.menurecyclerview;

public interface OnItemClickCallback {
    void onItemCilcked(Menu menu);
}
