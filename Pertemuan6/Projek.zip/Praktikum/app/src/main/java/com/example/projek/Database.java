package com.example.projek;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import androidx.annotation.Nullable;

public class Database extends SQLiteOpenHelper {

    private static final String DB_ANIME = "db_anime";
    private static final String KODE = "kode";
    private static final String NM_KARAKTER = "nm_karakter";
    private static final String TABEL_ANIME = "tabel_anime";
    private static final String KELAMIN = "kelamin";
    private static final String USIA = "usia";
    private static final String TINGGI = "tinggi";

    public Database(@Nullable Context context) {
        super(context, DB_ANIME, null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String nama_tabel = "create table "+TABEL_ANIME+ "(" + KODE + " integer primary key autoincrement, " + NM_KARAKTER + " text )";
        db.execSQL(nama_tabel);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

    }

    public boolean tambahData(String nama) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(NM_KARAKTER, nama);

        long result = db.insert(TABEL_ANIME,null,contentValues);
        return result != -1;
    }

    public Cursor tampilAnime() {
        SQLiteDatabase db = this.getWritableDatabase();
        String sql = "select * from " + TABEL_ANIME;
        Cursor cursor = db.rawQuery(sql,null);

        return cursor;
    }
}
