package com.example.projekuas;

public class Produk {
    private String kdprdk;
    private String nmprdk;
    private String deskripsi;
    private String harga;
    private String gambar;

    public Produk (){

    }

    public Produk(String kdprdk,String nmprdk,String deskripsi,String harga,String gambar){
        this.kdprdk = kdprdk;
        this.nmprdk = nmprdk;
        this.deskripsi = deskripsi;
        this.harga = harga;
        this.gambar = gambar;
    }

    public String getKdprdk() {
        return kdprdk;
    }

    public void setKdprdk(String kdprdk) {
        this.kdprdk = kdprdk;
    }

    public String getNmprdk() {
        return nmprdk;
    }

    public void setNmprdk(String nmprdk) {
        this.nmprdk = nmprdk;
    }

    public String getDeskripsi() {
        return deskripsi;
    }

    public void setDeskripsi(String deskripsi) {
        this.deskripsi = deskripsi;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getGambar() {
        return "http://10.0.2.2/smt5/ppb/LatihanUas/1/uploads/"+gambar;
    }

    public void setGambar(String gambar) {
        this.gambar = gambar;
    }

}
