package com.example.projekuas;

import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;

public class UpdateActivity extends AppCompatActivity {
    TextView kdedit,NamaEdit, DeskripsiEdit, HargaEdit, images;
    String id, NamaPrdk, DeskripsiPrdk, HargaPrdk, gbr;
    String id2, NamaPrdk2, DeskripsiPrdk2, HargaPrdk2, gbr2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        kdedit = findViewById(R.id.edit_kd_prd);
        NamaEdit = findViewById(R.id.edit_nm_prd);
        DeskripsiEdit = findViewById(R.id.edit_deskripsi);
        HargaEdit = findViewById(R.id.edit_harga);
        images = findViewById(R.id.edit_gambar);
        getAndSetIntentData();
    }

    void getAndSetIntentData() {
        if (getIntent().hasExtra("Kdprdk2") && getIntent().hasExtra("Namaprdk2") && getIntent().hasExtra("Hargaprdk2") && getIntent().hasExtra("deskripsi2") && getIntent().hasExtra("gmbr2")) {
            id = getIntent().getStringExtra("Kdprdk2");
            NamaPrdk = getIntent().getStringExtra("Namaprdk2");
            DeskripsiPrdk = getIntent().getStringExtra("deskripsi2");
            HargaPrdk = getIntent().getStringExtra("Hargaprdk2");
            gbr = getIntent().getStringExtra("gmbr2");
            kdedit.setText(id);
            NamaEdit.setText(NamaPrdk);
            DeskripsiEdit.setText(DeskripsiPrdk);
            HargaEdit.setText(HargaPrdk);
            images.setText(gbr);
            Log.d("stev", NamaPrdk + " " + DeskripsiPrdk + " " + HargaPrdk);
        } else {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }

    public void EDIT(View view) {
        final String kode = kdedit.getText().toString();
        final String nama = NamaEdit.getText().toString();
        final String harga = HargaEdit.getText().toString();
        final String deskripsi = DeskripsiEdit.getText().toString();
        final String gambar = images.getText().toString();

        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Updating....");
        progressDialog.show();
        StringRequest request = new StringRequest(Request.Method.POST,
                "http://10.0.2.2/smt5/ppb/LatihanUas/1/updatedata.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equalsIgnoreCase("Data Updated")) {
                    Toast.makeText(UpdateActivity.this, "Data Updated",
                            Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                    Intent intent = new Intent(getBaseContext(),
                            MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(UpdateActivity.this, response, Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(UpdateActivity.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                progressDialog.dismiss();
            }
        }) {
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String,String> params = new HashMap<String,String>();
                params.put("kd", kode);
                params.put("produk", nama);
                params.put("deskripsi", deskripsi);
                params.put("harga", harga);
                params.put("gambar", gambar);
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(UpdateActivity.this);
        requestQueue.add(request);
        Intent intent = new Intent(UpdateActivity.this, MainActivity.class);
        startActivity(intent);
    }

    public void BACK(View view) {
        Intent intent = new Intent(UpdateActivity.this, MainActivity.class);
        startActivity(intent);
    }

}