package com.example.projekuas;

import androidx.appcompat.app.AppCompatActivity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.drawable.Drawable;
import android.os.AsyncTask;
import android.os.Bundle;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.io.File;
import java.io.InputStream;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

public class MainActivity2 extends AppCompatActivity {

    TextView kdedit,NamaEdit, DeskripsiEdit, HargaEdit;
    String id, NamaPrdk, DeskripsiPrdk, HargaPrdk, gbr;
    String id2, NamaPrdk2, DeskripsiPrdk2, HargaPrdk2, gbr2;
    ImageView images;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        kdedit = findViewById(R.id.txt_kode_produk2);
        NamaEdit = findViewById(R.id.txt_nama_produk2);
        DeskripsiEdit = findViewById(R.id.txt_deskripsi_produk2);
        HargaEdit = findViewById(R.id.txt_harga_produk2);
        images = findViewById(R.id.img_card2);
        getAndSetIntentData();
        new DownloadImageTask((ImageView) findViewById(R.id.img_card2)).execute(gbr);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }

    public void editData(View view) {
        Intent intent = new Intent(MainActivity2.this,
                UpdateActivity.class);
        id2 = kdedit.getText().toString();
        NamaPrdk2 = NamaEdit.getText().toString();
        DeskripsiPrdk2 = DeskripsiEdit.getText().toString();
        HargaPrdk2 = HargaEdit.getText().toString();
        gbr2 = getIntent().getStringExtra("gmbr");
        intent.putExtra("Kdprdk2", id);
        intent.putExtra("Namaprdk2", NamaPrdk);
        intent.putExtra("Hargaprdk2", HargaPrdk);
        intent.putExtra("deskripsi2", DeskripsiPrdk);
        intent.putExtra("gmbr2", gbr);
        startActivity(intent);
    }

    public void deleteData(View view) {
        String kode = getIntent().getStringExtra("Kdprdk");
        deleteData2(kode);
    }

    private void deleteData2(final String kode) {
        StringRequest request = new StringRequest(Request.Method.POST,
                "http://10.0.2.2/smt5/ppb/LatihanUas/1/deletedata.php", new Response.Listener<String>() {
            @Override
            public void onResponse(String response) {
                if (response.equalsIgnoreCase("Data Deleted")) {
                    Toast.makeText(MainActivity2.this, "Data Deleted Successfully", Toast.LENGTH_SHORT).show();
                            Intent intent = new Intent(getBaseContext(), MainActivity.class);
                    startActivity(intent);
                } else {
                    Toast.makeText(MainActivity2.this, "Data Deleted",
                            Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent(getBaseContext(),
                            MainActivity.class);
                    startActivity(intent);
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(MainActivity2.this, error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }) {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<String,String>();
                    params.put("kdprdk", kode);
                    return params;
                }
        };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(request);
    }

    private class DownloadImageTask extends AsyncTask<String, Void, Bitmap> {
        ImageView bmImage;

        public DownloadImageTask(ImageView bmImage) {
            this.bmImage = bmImage;
        }

        protected Bitmap doInBackground(String... urls) {
            String urldisplay = urls[0];
            Bitmap mIcon11 = null;
            try {
                InputStream in = new java.net.URL(urldisplay).openStream();
                mIcon11 = BitmapFactory.decodeStream(in);
            } catch (Exception e) {
                Log.e("Error", e.getMessage());
                e.printStackTrace();
            }
            return mIcon11;
        }

        protected void onPostExecute(Bitmap result) {
            bmImage.setImageBitmap(result);
        }
    }

    void getAndSetIntentData() {
        if (getIntent().hasExtra("Kdprdk") && getIntent().hasExtra("Namaprdk") && getIntent().hasExtra("Hargaprdk") && getIntent().hasExtra("deskripsi") && getIntent().hasExtra("gmbr")) {
            id = getIntent().getStringExtra("Kdprdk");
            NamaPrdk = getIntent().getStringExtra("Namaprdk");
            DeskripsiPrdk = getIntent().getStringExtra("deskripsi");
            HargaPrdk = getIntent().getStringExtra("Hargaprdk");
            gbr = getIntent().getStringExtra("gmbr");
            kdedit.setText(id);
            NamaEdit.setText(NamaPrdk);
            DeskripsiEdit.setText(DeskripsiPrdk);
            HargaEdit.setText(HargaPrdk);
            Log.d("stev", NamaPrdk + " " + DeskripsiPrdk + " " + HargaPrdk);
        } else {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }

}