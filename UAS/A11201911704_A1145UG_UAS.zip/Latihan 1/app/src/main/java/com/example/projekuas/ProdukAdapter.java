package com.example.projekuas;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.bumptech.glide.Glide;
import com.squareup.picasso.Picasso;
import java.util.ArrayList;

public class ProdukAdapter extends RecyclerView.Adapter<ProdukAdapter.ProdukViewHolder> {
    public interface ItemClickListener{
        void onClick(View view, int position);
    }
    private ArrayList<Produk> dataList;
    private String KEY_TOT = "TOT";
    private double tot=0;
    Context context;

    int gambar[] = {R.drawable.img1, R.drawable.img2, R.drawable.img3, R.drawable.img4, R.drawable.img5};
    public ProdukAdapter(ArrayList<Produk> dataList, Context context) {
        this.context = context;
        this.dataList = dataList;
    }
    private ItemClickListener clickListener;

    @Override
    public ProdukViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.list_item, parent, false);
        return new ProdukViewHolder(view);
    }

    @Override
    public void onBindViewHolder(final ProdukViewHolder holder, int
            position) {
        holder.txtKode.setText(dataList.get(position).getKdprdk());
        holder.txtNama.setText(dataList.get(position).getNmprdk());
        holder.txtHarga.setText(dataList.get(position).getHarga());
        holder.txtDeskripsi.setText(dataList.get(position).getDeskripsi());
        Glide.with(context)
                .load(dataList.get(position).getGambar())
                .thumbnail(0.5f)
                .into(holder.icon);
    }

    @Override
    public int getItemCount() {
        return (dataList != null) ? dataList.size() : 0;
    }

    public void setClickListener(ItemClickListener clickListener) {
        this.clickListener = clickListener;
    }

    public class ProdukViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        private TextView txtKode, txtNama,txtHarga,txtDeskripsi;
        private ImageView icon;
        public ProdukViewHolder(View itemView) {
            super(itemView);
            txtKode = (TextView)
                    itemView.findViewById(R.id.txt_kode_produk);
            txtNama = (TextView)
                    itemView.findViewById(R.id.txt_nama_produk);
            txtHarga = (TextView)
                    itemView.findViewById(R.id.txt_harga_produk);
            txtDeskripsi = (TextView)
                    itemView.findViewById(R.id.txt_deskripsi_produk);
            icon = (ImageView) itemView.findViewById(R.id.img_card);
            itemView.setTag(itemView);
            itemView.setOnClickListener(this);
            txtNama.setOnClickListener(this);
            icon.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            if (clickListener != null) {
                clickListener.onClick(view, getAdapterPosition());
            }
        }
    }

    public double getTot(){
        return tot;
    }

    public void setTot(double tot){
        this.tot = tot;
    }

}
