package com.example.projekuas;

import androidx.appcompat.app.AppCompatActivity;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import com.example.projekuas.Util.ServerAPI;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.example.projekuas.Util.ServerAPI;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity implements ProdukAdapter.ItemClickListener {

    RecyclerView mRecyclerview;
    RecyclerView.Adapter mAdapter;
    RecyclerView.LayoutManager mManager;
    ArrayList<Produk> mItems;
    Button btnInsert, btnDelete;
    ProgressDialog pd;
    private ProdukAdapter adapter;
    private ArrayList<Produk> produkArrayList;
    private ArrayList<String> listGambar;
    ViewFlipper v_flipper;
    public double tot=0;
    String dataProduk[] = null;
    String dS[] = null;
    String kdprdk, NamaPrdk, DeskripsiPrdk, HargaPrdk, gambar;
    public String total2;
    public int tot1=0;
    int images[]={R.drawable.img1,R.drawable.img2,R.drawable.img3,R.drawable.img4,R.drawable.img5,R.drawable.img6};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        v_flipper = findViewById(R.id.v_flipper);

        for (int i=0; i<images.length; i++){
            fliverImages(images[i]);
        }

        for (int image: images) {
            fliverImages(image);
        }

        mRecyclerview = (RecyclerView)
                findViewById(R.id.recycler_view);
        pd = new ProgressDialog(MainActivity.this);
        mItems = new ArrayList<>();

        loadJson();
        mAdapter = new ProdukAdapter(mItems,this);
        adapter= new ProdukAdapter(mItems,this);
        GridLayoutManager layoutManager=new GridLayoutManager(this,2);
        mRecyclerview.setLayoutManager(layoutManager);
        mRecyclerview.setAdapter(adapter);
        adapter.setClickListener(this);
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();
        if (id == R.id.action_about) {
            startActivity(new Intent(this, AboutActivity.class));
        }else if (item.getItemId() == R.id.action_tambah) {
            startActivity(new Intent(this, TambahActivity.class));
        }else if (item.getItemId() == R.id.action_update) {
            startActivity(new Intent(this, UpdateAccountActivity.class));
        } else if (item.getItemId() == R.id.action_maps) {
            startActivity(new Intent(this, MyLBS.class));
        }
        return super.onOptionsItemSelected(item);
    }

    public void onClick(View view, int position) {
        final Produk makanan = mItems.get(position);
        switch (view.getId()) {
            case R.id.txt_nama_produk:
                Toast.makeText(this,"OKE " + makanan.getNmprdk(),Toast.LENGTH_SHORT).show();
                kdprdk = makanan.getKdprdk();
                NamaPrdk = makanan.getNmprdk();
                HargaPrdk = makanan.getHarga();
                DeskripsiPrdk = makanan.getDeskripsi();
                gambar = makanan.getGambar();

                Intent intent = new Intent(MainActivity.this, MainActivity2.class);
                intent.putExtra("Kdprdk", kdprdk);
                intent.putExtra("Namaprdk", NamaPrdk);
                intent.putExtra("Hargaprdk", HargaPrdk);
                intent.putExtra("deskripsi", DeskripsiPrdk);
                intent.putExtra("gmbr", gambar);

                startActivity(intent);
                return;

            case R.id.img_card:
                tot = tot+Double.parseDouble(makanan.getHarga());
                Toast.makeText(this,"Gambar....." + makanan.getNmprdk(),Toast.LENGTH_SHORT).show();
                TextView txtTot=(TextView) findViewById(R.id.totalPrice);
                txtTot.setText(""+tot);
                return;

//            default:
//                Toast.makeText(this,"lainnya..... -> " + makanan.getNmprdk()+ " Rp. "+tot ,Toast.LENGTH_SHORT).show();
//                break;
        }
    }

    private void loadJson() {
        pd.setMessage("Mengambil Data");
        pd.setCancelable(false);
        pd.show();
        JsonArrayRequest reqData = new JsonArrayRequest(Request.Method.POST, ServerAPI.URL_DATA, null, new Response.Listener<JSONArray>() {
            @Override
            public void onResponse(JSONArray response) {
                pd.cancel();
                Log.d("volley", "response : " + response.toString());
                for (int i = 0; i < response.length(); i++) {
                    try {
                        JSONObject data = response.getJSONObject(i);
                        Produk md = new Produk();
                        md.setKdprdk(data.getString("kd"));
                        md.setNmprdk(data.getString("produk"));
                        md.setDeskripsi(data.getString("deskripsi"));
                        md.setHarga(data.getString("harga"));
                        md.setGambar(data.getString("gambar"));
                        mItems.add(md);
                    } catch (JSONException e) {
                        e.printStackTrace();
                    }
                }
                adapter.notifyDataSetChanged();
            }
        },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                        pd.cancel();
                        Log.d("volley", "error : " + error.getMessage());
                    }
                });
        com.example.projekuas.Util.AppController.getInstance().addToRequestQueue(reqData);
    }

    public void ambildata() {
        listGambar= new ArrayList<String>();
        listGambar.add("img1");
        listGambar.add("img2");
        listGambar.add("img3");
        listGambar.add("img4");
        listGambar.add("img5");
        listGambar.add("img6");
    }

    public void checkout(View view) {
        DecimalFormat decimalFormat = new DecimalFormat("#,##0.00");
        Toast.makeText(this,"Total Rp. "+ decimalFormat.format(tot),Toast.LENGTH_SHORT).show();
        Intent intent = new Intent(MainActivity.this, TagihanActivity.class);
        TextView txtTot1=(TextView) findViewById(R.id.totalPrice);
        tot1 = (int)tot;
        total2 = String.valueOf(tot1);
        intent.putExtra("TAGIHAN", total2);
        startActivity(intent);
    }

    public void fliverImages(int images){
        ImageView imageView = new ImageView(this);
        imageView.setBackgroundResource(images);
        v_flipper.addView(imageView);
        v_flipper.setFlipInterval(4000);
        v_flipper.setAutoStart(true);
        v_flipper.setInAnimation(this,android.R.anim.slide_in_left);
        v_flipper.setOutAnimation(this,android.R.anim.slide_out_right);
    }

}