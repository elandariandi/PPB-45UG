package com.example.projekuas.Util;

public class ServerAPI {
    public static final String URL_DATA =
            "http://10.0.2.2/smt5/ppb/LatihanUas/1/viewdata.php";
    public static final String URL_INSERT =
            "http://10.0.2.2/smt5/ppb/LatihanUas/1/createdata.php";
    public static final String URL_DELETE =
            "http://10.0.2.2/smt5/ppb/LatihanUas/1/deletedata.php";
    public static final String URL_UPDATE =
            "http://10.0.2.2/smt5/ppb/LatihanUas/1/updatedata.php";
}
