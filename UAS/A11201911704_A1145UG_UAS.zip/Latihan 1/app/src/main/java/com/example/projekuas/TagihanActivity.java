package com.example.projekuas;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

public class TagihanActivity extends AppCompatActivity {
    private EditText editkembali, editbayar, editagihan;
    TextView tagihan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tagihan);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        editkembali = (EditText) findViewById(R.id.kembalian);
        editbayar = (EditText) findViewById(R.id.bayar);
        editagihan = (EditText) findViewById(R.id.tv_default);
        tagihan = findViewById(R.id.tv_default);
        Intent intent = getIntent();
        String namaAplikasi = intent.getStringExtra("TAGIHAN");
        tagihan.setText(namaAplikasi);

        editagihan.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                editkembali.setText(addNumbers());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });

        editbayar.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                editkembali.setText(addNumbers());
            }

            @Override
            public void afterTextChanged(Editable editable) {

            }
        });
    }

    private String addNumbers() {
        int number1;
        int number2, numhasil;
        String hasil;
        if(editbayar.getText().toString() != "" &&
                editbayar.getText().length() > 0) {
            number1 = Integer.parseInt(editbayar.getText().toString());
        } else {
            number1 = 0;
        }
        if(editagihan.getText().toString() != "" &&
                editagihan.getText().length() > 0) {
            number2 = Integer.parseInt(editagihan.getText().toString());
        } else {
            number2 = 0;
        }
        if (number1-number2 <= 0){
            numhasil = 0;
            hasil = Integer.toString(numhasil);
            return hasil ;
        }else{
            hasil = Integer.toString(number1 - number2);
            return hasil ;
        }
    }

}