package com.example.projekuas;

import androidx.appcompat.app.AppCompatActivity;
import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;

public class TambahActivity extends AppCompatActivity {
    EditText txtKode, txtNama, txtHarga, txtDeskripsi, txtGambar;
    Button btn_insert;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tambah);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        txtKode = findViewById(R.id.tambah_kd_prd);
        txtNama = findViewById(R.id.tambah_nm_prd);
        txtHarga = findViewById(R.id.tambah_harga);
        txtDeskripsi = findViewById(R.id.tambah_deskripsi);
        txtGambar = findViewById(R.id.tambah_gambar);
        btn_insert = findViewById(R.id.tambah_btn);

        btn_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertData();
            }
        });
    }

    private void insertData() {
        final String kode = txtKode.getText().toString().trim();
        final String nama = txtNama.getText().toString().trim();
        final String harga = txtHarga.getText().toString().trim();
        final String deskripsi = txtDeskripsi.getText().toString().trim();
        final String gambar = txtGambar.getText().toString().trim();
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Loading...");

        if (kode.isEmpty()) {
            Toast.makeText(this, "Enter Kode", Toast.LENGTH_SHORT).show();
            return;
        } else if (nama.isEmpty()) {
            Toast.makeText(this, "Enter Nama", Toast.LENGTH_SHORT).show();
            return;
        } else if (harga.isEmpty()) {
            Toast.makeText(this, "Enter Harga", Toast.LENGTH_SHORT).show();
            return;
        } else if (deskripsi.isEmpty()) {
            Toast.makeText(this, "Enter Deskripsi",
                    Toast.LENGTH_SHORT).show();
            return;
        } else if (gambar.isEmpty()) {
            Toast.makeText(this, "Enter gambar",
                    Toast.LENGTH_SHORT).show();
            return;
        } else {
            progressDialog.show();
            StringRequest request = new StringRequest(Request.Method.POST, "http://10.0.2.2/smt5/ppb/LatihanUas/1/createdata.php", new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    if (response.equalsIgnoreCase("Data Inserted")) {
                        Toast.makeText(TambahActivity.this, "Data Inserted", Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                        Intent intent = new Intent(getBaseContext(), MainActivity.class);
                        startActivity(intent);
                    } else {
                        Toast.makeText(TambahActivity.this, response, Toast.LENGTH_SHORT).show();
                        progressDialog.dismiss();
                    }
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(TambahActivity.this, error.getMessage(),
                            Toast.LENGTH_SHORT).show();
                    progressDialog.dismiss();
                }
            }
            ) {
                @Override
                protected Map<String, String> getParams() throws
                        AuthFailureError {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("kd", kode);
                    params.put("produk", nama);
                    params.put("harga", harga);
                    params.put("deskripsi", deskripsi);
                    params.put("gambar", gambar);
                    return params;
                }
            };
            RequestQueue requestQueue =
                    Volley.newRequestQueue(TambahActivity.this);
            requestQueue.add(request);
            Intent intent = new Intent(TambahActivity.this, MainActivity.class);
            startActivity(intent);
        }
    }

    @Override
    public void onBackPressed() {
        super.onBackPressed();
        finish();
    }

    public void BACK(View view) {
        Intent intent = new Intent(TambahActivity.this,
                MainActivity.class);
        startActivity(intent);
    }
}